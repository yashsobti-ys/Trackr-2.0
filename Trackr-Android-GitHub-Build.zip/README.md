# Trackr Android Project

This is the native Android project extracted from the Trackr project ZIP. It uses Kotlin, Jetpack Compose, Room, and Gradle.

## Build an APK online with GitHub Actions

1. Create a GitHub account or sign in at https://github.com.
2. Create a **new repository** (a private repository is fine).
3. Extract this ZIP on your computer. The folder you extract contains `app/`, `gradle/`, `build.gradle.kts`, `settings.gradle.kts`, and `.github/`. These must be at the **repository root**, not inside another nested `android/` folder.
4. Upload all extracted files and folders to the repository root, including the hidden `.github` folder. Commit the files to `main`.
5. Open the repository's **Actions** tab. Select **Trackr Android APK Build**. If needed, click **Run workflow**.
6. Wait for the workflow to finish. Open the workflow run and look under **Artifacts** for `trackr-debug-apk`. Download it.
7. If the artifact exists, extract it if needed to get `app-debug.apk`, then transfer it to your Android phone and tap it to install. You may need to allow your file manager or browser to install unknown apps. Only install APKs you trust.

The workflow builds with Gradle 8.7 and JDK 17 without depending on a checked-in Gradle wrapper JAR. It uploads the APK when one was produced, even if unit tests fail; check the workflow result and test reports before relying on the build.

## Local build

Install JDK 17, Android SDK platform 34, and Gradle 8.7. From this directory run:

```bash
gradle assembleDebug
gradle testDebugUnitTest
```

The debug APK is expected at `app/build/outputs/apk/debug/app-debug.apk`.

## Important status note

The source project has not been compiled or tested in the environment that prepared this ZIP. The GitHub Actions workflow is the next verification step. A successful APK build does not by itself prove every feature works correctly; review test results and test the app on your phone.
