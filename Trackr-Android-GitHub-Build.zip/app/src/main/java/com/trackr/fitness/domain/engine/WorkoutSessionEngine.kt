package com.trackr.fitness.domain.engine

enum class SessionState {
    IDLE,
    ACTIVE,
    PAUSED,
    COMPLETED,
    CANCELLED
}

data class ActiveWorkoutSet(
    val id: String,
    val setNumber: Int,
    val type: String, // warmup, normal, drop, failure
    val weight: Double,
    val reps: Int,
    val rpe: Double? = null,
    val isCompleted: Boolean = false,
    val previousWeight: Double? = null,
    val previousReps: Int? = null
)

data class ActiveWorkoutExercise(
    val id: String,
    val exerciseId: String,
    val exerciseName: String,
    val muscleGroup: String,
    val equipment: String,
    val sets: List<ActiveWorkoutSet>,
    val notes: String? = null
)

data class ActiveSessionSnapshot(
    val sessionId: String,
    val title: String,
    val state: SessionState,
    val startTimeMs: Long,
    val elapsedTimeSeconds: Long,
    val exercises: List<ActiveWorkoutExercise>,
    val notes: String? = null
)

class WorkoutSessionEngine(
    private var currentSession: ActiveSessionSnapshot? = null
) {
    fun getCurrentSession(): ActiveSessionSnapshot? = currentSession

    fun startSession(sessionId: String, title: String, exercises: List<ActiveWorkoutExercise>): ActiveSessionSnapshot {
        val session = ActiveSessionSnapshot(
            sessionId = sessionId,
            title = title,
            state = SessionState.ACTIVE,
            startTimeMs = System.currentTimeMillis(),
            elapsedTimeSeconds = 0,
            exercises = exercises
        )
        currentSession = session
        return session
    }

    fun recoverSession(snapshot: ActiveSessionSnapshot): ActiveSessionSnapshot {
        // Enforce crash recovery invariant: an interrupted workout retains active state and elapsed duration
        currentSession = snapshot.copy(state = SessionState.ACTIVE)
        return currentSession!!
    }

    fun toggleSetCompletion(exerciseId: String, setId: String): ActiveSessionSnapshot? {
        val session = currentSession ?: return null
        val updatedExercises = session.exercises.map { ex ->
            if (ex.id == exerciseId) {
                val updatedSets = ex.sets.map { set ->
                    if (set.id == setId) {
                        set.copy(isCompleted = !set.isCompleted)
                    } else set
                }
                ex.copy(sets = updatedSets)
            } else ex
        }
        currentSession = session.copy(exercises = updatedExercises)
        return currentSession
    }

    fun completeSession(): ActiveSessionSnapshot? {
        val session = currentSession ?: return null
        if (session.state == SessionState.COMPLETED) return session
        currentSession = session.copy(state = SessionState.COMPLETED)
        return currentSession
    }

    fun cancelSession(): ActiveSessionSnapshot? {
        val session = currentSession ?: return null
        currentSession = session.copy(state = SessionState.CANCELLED)
        return currentSession
    }
}
