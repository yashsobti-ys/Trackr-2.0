package com.trackr.fitness.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "exercises")
data class ExerciseEntity(
    @PrimaryKey val id: String,
    val name: String,
    val muscleGroup: String, // e.g., "Chest", "Back", "Quads"
    val equipment: String,   // e.g., "Barbell", "Dumbbell"
    val category: String,    // "strength", "bodyweight", "cardio"
    val instructions: String,
    val isCustom: Boolean = false
)

@Entity(tableName = "routines")
data class RoutineEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val category: String,
    val estimatedMinutes: Int,
    val lastPerformed: Long? = null
)

@Entity(
    tableName = "routine_exercises",
    foreignKeys = [
        ForeignKey(
            entity = RoutineEntity::class,
            parentColumns = ["id"],
            childColumns = ["routineId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("routineId")]
)
data class RoutineExerciseEntity(
    @PrimaryKey val id: String,
    val routineId: String,
    val exerciseId: String,
    val exerciseName: String,
    val orderIndex: Int,
    val targetSets: Int,
    val targetReps: String,
    val restTimerSeconds: Int,
    val notes: String? = null
)

@Entity(tableName = "workout_sessions")
data class WorkoutSessionEntity(
    @PrimaryKey val id: String,
    val title: String,
    val startTime: Long,
    val endTime: Long? = null,
    val durationSeconds: Long,
    val status: String, // "idle", "active", "paused", "completed", "cancelled"
    val routineId: String? = null,
    val notes: String? = null,
    val totalVolume: Double = 0.0
)

@Entity(
    tableName = "workout_exercises",
    foreignKeys = [
        ForeignKey(
            entity = WorkoutSessionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("sessionId")]
)
data class WorkoutExerciseEntity(
    @PrimaryKey val id: String,
    val sessionId: String,
    val exerciseId: String,
    val exerciseName: String,
    val muscleGroup: String,
    val equipment: String,
    val orderIndex: Int,
    val notes: String? = null,
    val supersetGroup: String? = null
)

@Entity(
    tableName = "workout_sets",
    foreignKeys = [
        ForeignKey(
            entity = WorkoutExerciseEntity::class,
            parentColumns = ["id"],
            childColumns = ["workoutExerciseId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("workoutExerciseId")]
)
data class WorkoutSetEntity(
    @PrimaryKey val id: String,
    val workoutExerciseId: String,
    val setNumber: Int,
    val type: String, // "warmup", "normal", "drop", "failure"
    val weight: Double,
    val reps: Int,
    val rpe: Double? = null,
    val isCompleted: Boolean,
    val previousWeight: Double? = null,
    val previousReps: Int? = null
)

@Entity(tableName = "personal_records")
data class PersonalRecordEntity(
    @PrimaryKey val id: String,
    val exerciseId: String,
    val exerciseName: String,
    val date: Long,
    val type: String, // "max_weight", "max_reps", "max_1rm", "max_volume"
    val value: Double,
    val weight: Double,
    val reps: Int,
    val workoutSessionId: String? = null
)

@Entity(tableName = "body_measurements")
data class BodyMeasurementEntity(
    @PrimaryKey val id: String,
    val date: Long,
    val weightKg: Double? = null,
    val bodyFatPercentage: Double? = null,
    val chestCm: Double? = null,
    val waistCm: Double? = null,
    val hipsCm: Double? = null,
    val armsCm: Double? = null,
    val thighsCm: Double? = null,
    val notes: String? = null
)

@Entity(tableName = "journal_entries")
data class JournalEntryEntity(
    @PrimaryKey val id: String,
    val date: Long,
    val title: String,
    val content: String,
    val energyLevel: Int? = null
)
