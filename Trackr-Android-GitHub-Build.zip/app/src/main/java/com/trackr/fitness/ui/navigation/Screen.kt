package com.trackr.fitness.ui.navigation

sealed class Screen(val route: String, val title: String) {
    object Home : Screen("home", "Home")
    object Routines : Screen("routines", "Workouts")
    object ActiveWorkout : Screen("active_workout", "Active Session")
    object Progress : Screen("progress", "Analytics")
    object Utilities : Screen("utilities", "Tools")
    object Settings : Screen("settings", "Settings")
}
