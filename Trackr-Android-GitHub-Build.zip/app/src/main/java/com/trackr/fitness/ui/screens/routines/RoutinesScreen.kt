package com.trackr.fitness.ui.screens.routines

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trackr.fitness.ui.theme.Charcoal800
import com.trackr.fitness.ui.theme.LimeGreen
import com.trackr.fitness.ui.theme.TextMuted
import com.trackr.fitness.ui.theme.TextSecondary

@Composable
fun RoutinesScreen(
    onStartRoutine: (routineId: String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Workouts & Routines",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Custom templates and starter splits",
                        fontSize = 13.sp,
                        color = TextSecondary
                    )
                }

                FilledTonalButton(
                    onClick = {},
                    colors = ButtonDefaults.filledTonalButtonColors(containerColor = LimeGreen)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("New", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Section: PPL Splits
        item {
            Text("Push Pull Legs Split", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = LimeGreen)
        }

        item {
            RoutineItemCard(
                title = "Push Day (Hypertrophy)",
                description = "Chest, Shoulders & Triceps with compound barbell focus.",
                exercises = listOf("Barbell Bench Press", "Incline Dumbbell Press", "Dumbbell Lateral Raise", "Tricep Pushdown"),
                onStart = { onStartRoutine("push") }
            )
        }

        item {
            RoutineItemCard(
                title = "Pull Day (Hypertrophy)",
                description = "Deadlifts, Lat Pulldowns, Dumbbell Rows & Biceps curls.",
                exercises = listOf("Conventional Deadlift", "Lat Pulldown", "Bent-Over Row", "Barbell Curl"),
                onStart = { onStartRoutine("pull") }
            )
        }

        item {
            RoutineItemCard(
                title = "Leg Day (Squats & Quads)",
                description = "Back Squats, Romanian Deadlifts, Leg Press & Calves.",
                exercises = listOf("Barbell Back Squat", "Romanian Deadlift", "Leg Press", "Standing Calf Raise"),
                onStart = { onStartRoutine("legs") }
            )
        }
    }
}

@Composable
fun RoutineItemCard(
    title: String,
    description: String,
    exercises: List<String>,
    onStart: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Charcoal800),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Button(
                    onClick = onStart,
                    colors = ButtonDefaults.buttonColors(containerColor = LimeGreen),
                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Start", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }

            Text(text = description, fontSize = 13.sp, color = TextSecondary, modifier = Modifier.padding(vertical = 6.dp))
            Spacer(modifier = Modifier.height(4.dp))

            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                exercises.forEach { ex ->
                    Text(text = "• $ex", fontSize = 12.sp, color = TextMuted)
                }
            }
        }
    }
}
