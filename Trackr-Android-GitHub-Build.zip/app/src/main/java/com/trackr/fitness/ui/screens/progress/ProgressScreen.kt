package com.trackr.fitness.ui.screens.progress

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trackr.fitness.ui.theme.*

@Composable
fun ProgressScreen() {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Analytics & Progress",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Personal records, volume trends & strength progression",
                    fontSize = 13.sp,
                    color = TextSecondary
                )
            }
        }

        // PR Trophy Showcase Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = LimeGreen)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Personal Records Wall", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
        }

        // PR Cards
        item {
            PRRecordCard("Barbell Bench Press", "205 lbs × 5 reps", "Est 1RM: 239 lbs")
        }
        item {
            PRRecordCard("Conventional Deadlift", "315 lbs × 5 reps", "Est 1RM: 367 lbs")
        }
        item {
            PRRecordCard("Barbell Back Squat", "255 lbs × 5 reps", "Est 1RM: 297 lbs")
        }

        // Volume breakdown
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Charcoal800),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Weekly Volume Trend", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Total lifted weight per week", fontSize = 12.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(14.dp))
                    
                    // Simple visual volume bars
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        VolumeBar("Week 1", 0.6f, "32k")
                        VolumeBar("Week 2", 0.75f, "38k")
                        VolumeBar("Week 3", 0.9f, "43k")
                        VolumeBar("Current", 0.95f, "45k")
                    }
                }
            }
        }
    }
}

@Composable
fun PRRecordCard(exerciseName: String, recordDetail: String, oneRepMax: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Charcoal800),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(exerciseName, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                Text(recordDetail, fontSize = 13.sp, color = LimeGreen, fontWeight = FontWeight.Medium)
            }
            Text(oneRepMax, fontSize = 12.sp, color = TextSecondary)
        }
    }
}

@Composable
fun VolumeBar(label: String, fraction: Float, displayVal: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Bottom
    ) {
        Text(displayVal, fontSize = 11.sp, color = LimeGreen, fontWeight = FontWeight.SemiBold)
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .width(36.dp)
                .height((80 * fraction).dp)
                .clip(RoundedCornerShape(6.dp))
                .background(LimeGreen)
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(label, fontSize = 11.sp, color = TextMuted)
    }
}
