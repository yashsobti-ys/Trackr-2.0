package com.trackr.fitness.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.trackr.fitness.ui.screens.home.HomeScreen
import com.trackr.fitness.ui.screens.routines.RoutinesScreen
import com.trackr.fitness.ui.screens.progress.ProgressScreen
import com.trackr.fitness.ui.screens.utilities.UtilitiesScreen
import com.trackr.fitness.ui.screens.workout.ActiveWorkoutScreen

@Composable
fun TrackrNavGraph() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar {
                val items = listOf(
                    Triple(Screen.Home, Icons.Default.Home, "Home"),
                    Triple(Screen.Routines, Icons.Default.FitnessCenter, "Workouts"),
                    Triple(Screen.ActiveWorkout, Icons.Default.PlayCircle, "Log"),
                    Triple(Screen.Progress, Icons.Default.ShowChart, "Progress"),
                    Triple(Screen.Utilities, Icons.Default.Build, "Tools")
                )

                items.forEach { (screen, icon, label) ->
                    NavigationBarItem(
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) },
                        selected = currentRoute == screen.route,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    onStartEmptyWorkout = { navController.navigate(Screen.ActiveWorkout.route) },
                    onNavigateToRoutines = { navController.navigate(Screen.Routines.route) }
                )
            }
            composable(Screen.Routines.route) {
                RoutinesScreen(
                    onStartRoutine = { navController.navigate(Screen.ActiveWorkout.route) }
                )
            }
            composable(Screen.ActiveWorkout.route) {
                ActiveWorkoutScreen(
                    onFinishWorkout = { navController.navigate(Screen.Home.route) }
                )
            }
            composable(Screen.Progress.route) {
                ProgressScreen()
            }
            composable(Screen.Utilities.route) {
                UtilitiesScreen()
            }
        }
    }
}
