package com.trackr.fitness.ui.screens.workout

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trackr.fitness.ui.theme.*

data class LocalWorkoutSet(
    val id: String,
    val setNum: Int,
    val prev: String,
    var weight: String,
    var reps: String,
    var isDone: Boolean = false
)

@Composable
fun ActiveWorkoutScreen(
    onFinishWorkout: () -> Unit
) {
    var workoutTitle by remember { mutableStateOf("Afternoon Workout") }
    var secondsElapsed by remember { mutableIntStateOf(1420) }
    
    // Sample active exercises with sets
    val sets1 = remember {
        mutableStateListOf(
            LocalWorkoutSet("s1", 1, "185 lbs × 8", "195", "8", true),
            LocalWorkoutSet("s2", 2, "195 lbs × 6", "205", "6", true),
            LocalWorkoutSet("s3", 3, "205 lbs × 5", "215", "5", false)
        )
    }

    val sets2 = remember {
        mutableStateListOf(
            LocalWorkoutSet("s4", 1, "65 lbs × 10", "70", "10", true),
            LocalWorkoutSet("s5", 2, "70 lbs × 8", "75", "8", false)
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header with Timer and Finish
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = workoutTitle,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Timer,
                            contentDescription = null,
                            tint = LimeGreen,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        val mins = secondsElapsed / 60
                        val secs = secondsElapsed % 60
                        Text(
                            text = String.format("%02d:%02d", mins, secs),
                            fontSize = 14.sp,
                            color = LimeGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }

                Button(
                    onClick = onFinishWorkout,
                    colors = ButtonDefaults.buttonColors(containerColor = LimeGreen),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Finish", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Rest timer banner
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Charcoal700)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Rest Timer", fontSize = 13.sp, color = TextSecondary)
                Text("01:15", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = LimeGreen)
                TextButton(onClick = {}) {
                    Text("+30s", color = LimeGreen)
                }
            }
        }

        // Exercise 1: Barbell Bench Press
        item {
            ExerciseWorkoutCard(
                exerciseName = "Barbell Bench Press",
                sets = sets1,
                onAddSet = {
                    val nextNum = sets1.size + 1
                    sets1.add(LocalWorkoutSet("s_${System.currentTimeMillis()}", nextNum, "-", "205", "5", false))
                }
            )
        }

        // Exercise 2: Incline Dumbbell Press
        item {
            ExerciseWorkoutCard(
                exerciseName = "Incline Dumbbell Press",
                sets = sets2,
                onAddSet = {
                    val nextNum = sets2.size + 1
                    sets2.add(LocalWorkoutSet("s_${System.currentTimeMillis()}", nextNum, "-", "70", "8", false))
                }
            )
        }

        // Add Exercise Button
        item {
            OutlinedButton(
                onClick = {},
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = LimeGreen)
            ) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Add Exercise")
            }
        }
    }
}

@Composable
fun ExerciseWorkoutCard(
    exerciseName: String,
    sets: MutableList<LocalWorkoutSet>,
    onAddSet: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Charcoal800),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = exerciseName,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(10.dp))

            // Table Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("SET", fontSize = 11.sp, color = TextMuted, modifier = Modifier.width(36.dp))
                Text("PREV", fontSize = 11.sp, color = TextMuted, modifier = Modifier.weight(1f))
                Text("LBS", fontSize = 11.sp, color = TextMuted, modifier = Modifier.width(60.dp))
                Text("REPS", fontSize = 11.sp, color = TextMuted, modifier = Modifier.width(50.dp))
                Text("DONE", fontSize = 11.sp, color = TextMuted, modifier = Modifier.width(40.dp))
            }
            Spacer(modifier = Modifier.height(6.dp))

            // Set Rows
            sets.forEachIndexed { index, setItem ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "${index + 1}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextSecondary,
                        modifier = Modifier.width(36.dp)
                    )
                    Text(
                        text = setItem.prev,
                        fontSize = 12.sp,
                        color = TextMuted,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = setItem.weight,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White,
                        modifier = Modifier.width(60.dp)
                    )
                    Text(
                        text = setItem.reps,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White,
                        modifier = Modifier.width(50.dp)
                    )
                    IconButton(
                        onClick = {
                            val cur = setItem.isDone
                            sets[index] = setItem.copy(isDone = !cur)
                        },
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (setItem.isDone) LimeGreen else Charcoal700)
                    ) {
                        Icon(
                            Icons.Default.Check,
                            contentDescription = "Complete",
                            tint = if (setItem.isDone) Color.Black else TextMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            TextButton(
                onClick = onAddSet,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            ) {
                Text("+ Add Set", color = LimeGreen, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}
