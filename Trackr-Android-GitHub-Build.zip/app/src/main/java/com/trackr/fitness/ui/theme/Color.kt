package com.trackr.fitness.ui.theme

import androidx.compose.ui.graphics.Color

val Charcoal900 = Color(0xFF0F1012)
val Charcoal800 = Color(0xFF18191D)
val Charcoal700 = Color(0xFF222328)
val Charcoal600 = Color(0xFF2E3036)
val BorderDark = Color(0xFF383A42)

val LimeGreen = Color(0xFFA3E635)
val LimeGreenDark = Color(0xFF84CC16)
val LimeGreenGlow = Color(0x33A3E635)

val TextPrimary = Color(0xFFF4F4F5)
val TextSecondary = Color(0xFFA1A1AA)
val TextMuted = Color(0xFF71717A)

val RedDanger = Color(0xFFEF4444)
val YellowWarn = Color(0xFFEAB308)
val BlueInfo = Color(0xFF3B82F6)
