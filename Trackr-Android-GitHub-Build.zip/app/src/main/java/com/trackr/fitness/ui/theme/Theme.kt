package com.trackr.fitness.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = LimeGreen,
    onPrimary = Charcoal900,
    primaryContainer = Charcoal700,
    onPrimaryContainer = LimeGreen,
    secondary = LimeGreenDark,
    background = Charcoal900,
    surface = Charcoal800,
    surfaceVariant = Charcoal700,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    error = RedDanger,
    outline = BorderDark
)

@Composable
fun TrackrTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
