package com.trackr.fitness.data.seed

import com.trackr.fitness.data.local.entity.ExerciseEntity
import com.trackr.fitness.data.local.entity.RoutineEntity
import com.trackr.fitness.data.local.entity.RoutineExerciseEntity

data class RoutineWithExercises(
    val routine: RoutineEntity,
    val exercises: List<RoutineExerciseEntity>
)

object SeedData {
    val defaultExercises = listOf(
        ExerciseEntity("ex-bench-press", "Barbell Bench Press", "Chest", "Barbell", "strength", "Lie on bench, grip bar slightly wider than shoulders, lower to mid chest and press up powerfully."),
        ExerciseEntity("ex-incline-db-press", "Incline Dumbbell Press", "Chest", "Dumbbell", "strength", "Bench set to 30-45 degrees, press dumbbells overhead with control."),
        ExerciseEntity("ex-dips-chest", "Chest Dips", "Chest", "Bodyweight", "bodyweight", "Lean forward ~30 degrees, descend until elbows reach 90 degrees, press up."),
        ExerciseEntity("ex-deadlift", "Conventional Barbell Deadlift", "Back", "Barbell", "strength", "Feet hip-width, hinge hips, drive floor away while keeping rigid spine."),
        ExerciseEntity("ex-barbell-row", "Bent-Over Barbell Row", "Back", "Barbell", "strength", "Hinge 45 degrees, pull bar to lower chest driving elbows back."),
        ExerciseEntity("ex-lat-pulldown", "Lat Pulldown", "Back", "Cable", "strength", "Pull bar to clavicle while driving elbows down and back."),
        ExerciseEntity("ex-pull-ups", "Pull-Up", "Back", "Bodyweight", "bodyweight", "Overhand grip, pull until chin clears the bar."),
        ExerciseEntity("ex-overhead-press", "Standing Overhead Press (OHP)", "Shoulders", "Barbell", "strength", "Grip at shoulders, brace core and glutes, press vertically overhead."),
        ExerciseEntity("ex-db-lateral-raise", "Dumbbell Lateral Raise", "Shoulders", "Dumbbell", "strength", "Lead with elbows out to sides to shoulder height."),
        ExerciseEntity("ex-barbell-squat", "Barbell Back Squat", "Quads", "Barbell", "strength", "Bar on upper traps, descend past parallel, drive through mid-foot."),
        ExerciseEntity("ex-leg-press", "Leg Press", "Quads", "Machine", "strength", "Feet shoulder-width on platform, lower knees to 90 degrees, press up."),
        ExerciseEntity("ex-romanian-deadlift", "Romanian Deadlift (RDL)", "Hamstrings", "Barbell", "strength", "Push hips back with soft knees, feel deep hamstring stretch, squeeze glutes to lockout."),
        ExerciseEntity("ex-barbell-curl", "Barbell Biceps Curl", "Biceps", "Barbell", "strength", "Pin elbows at sides, curl bar to shoulder level."),
        ExerciseEntity("ex-tricep-rope-pushdown", "Tricep Rope Pushdown", "Triceps", "Cable", "strength", "Push rope down spreading ends at bottom for peak triceps contraction.")
    )

    val defaultRoutines = listOf(
        RoutineWithExercises(
            routine = RoutineEntity("routine-push", "Push Day", "Chest, Shoulders & Triceps hypertrophy", "PPL", 60),
            exercises = listOf(
                RoutineExerciseEntity("re-1", "routine-push", "ex-bench-press", "Barbell Bench Press", 0, 4, "6-8", 150),
                RoutineExerciseEntity("re-2", "routine-push", "ex-incline-db-press", "Incline Dumbbell Press", 1, 3, "8-12", 90),
                RoutineExerciseEntity("re-3", "routine-push", "ex-db-lateral-raise", "Dumbbell Lateral Raise", 2, 4, "12-15", 60),
                RoutineExerciseEntity("re-4", "routine-push", "ex-tricep-rope-pushdown", "Tricep Rope Pushdown", 3, 3, "10-12", 60)
            )
        ),
        RoutineWithExercises(
            routine = RoutineEntity("routine-pull", "Pull Day", "Back, Rear Delts & Biceps", "PPL", 60),
            exercises = listOf(
                RoutineExerciseEntity("re-5", "routine-pull", "ex-deadlift", "Conventional Barbell Deadlift", 0, 3, "5", 180),
                RoutineExerciseEntity("re-6", "routine-pull", "ex-lat-pulldown", "Lat Pulldown", 1, 4, "8-10", 90),
                RoutineExerciseEntity("re-7", "routine-pull", "ex-barbell-curl", "Barbell Biceps Curl", 2, 3, "8-10", 60)
            )
        ),
        RoutineWithExercises(
            routine = RoutineEntity("routine-legs", "Leg Day", "Quads, Hamstrings & Calves", "PPL", 60),
            exercises = listOf(
                RoutineExerciseEntity("re-8", "routine-legs", "ex-barbell-squat", "Barbell Back Squat", 0, 4, "6-8", 150),
                RoutineExerciseEntity("re-9", "routine-legs", "ex-romanian-deadlift", "Romanian Deadlift (RDL)", 1, 3, "8-10", 120),
                RoutineExerciseEntity("re-10", "routine-legs", "ex-leg-press", "Leg Press", 2, 3, "10-12", 90)
            )
        )
    )
}
