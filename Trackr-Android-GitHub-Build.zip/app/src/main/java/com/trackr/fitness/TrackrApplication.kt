package com.trackr.fitness

import android.app.Application
import com.trackr.fitness.data.local.TrackrDatabase

class TrackrApplication : Application() {
    val database: TrackrDatabase by lazy { TrackrDatabase.getDatabase(this) }

    override fun onCreate() {
        super.onCreate()
    }
}
