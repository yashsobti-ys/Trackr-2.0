package com.trackr.fitness.domain.calculator

import kotlin.math.roundToInt

object FitnessCalculators {

    /**
     * Calculates estimated 1 Rep Max using the standard Epley formula:
     * 1RM = Weight * (1 + Reps / 30.0)
     */
    fun calculateEpley1RM(weight: Double, reps: Int): Double {
        if (weight <= 0.0 || reps <= 0) return 0.0
        if (reps == 1) return weight
        val raw = weight * (1.0 + reps / 30.0)
        return (raw * 10.0).roundToInt() / 10.0
    }

    /**
     * Calculates estimated 1 Rep Max using Brzycki formula:
     * 1RM = Weight * (36.0 / (37.0 - Reps))
     */
    fun calculateBrzycki1RM(weight: Double, reps: Int): Double {
        if (weight <= 0.0 || reps <= 0) return 0.0
        if (reps == 1) return weight
        if (reps >= 37) return calculateEpley1RM(weight, reps)
        val raw = weight * (36.0 / (37.0 - reps))
        return (raw * 10.0).roundToInt() / 10.0
    }

    data class PlateCount(
        val plateWeight: Double,
        val countPerSide: Int
    )

    data class PlateResult(
        val targetWeight: Double,
        val barWeight: Double,
        val weightPerSide: Double,
        val platesPerSide: List<PlateCount>,
        val actualTotalWeight: Double,
        val remainder: Double
    )

    val STANDARD_LBS = listOf(45.0, 35.0, 25.0, 10.0, 5.0, 2.5)
    val STANDARD_KG = listOf(25.0, 20.0, 15.0, 10.0, 5.0, 2.5, 1.25)

    fun calculatePlates(
        targetWeight: Double,
        barWeight: Double = 45.0,
        unit: String = "lbs"
    ): PlateResult {
        val plates = if (unit == "lbs") STANDARD_LBS else STANDARD_KG
        if (targetWeight <= barWeight) {
            return PlateResult(targetWeight, barWeight, 0.0, emptyList(), barWeight, 0.0)
        }

        var remainingPerSide = (targetWeight - barWeight) / 2.0
        val resultPlates = mutableListOf<PlateCount>()

        for (plate in plates) {
            if (remainingPerSide >= plate) {
                val count = (remainingPerSide / plate).toInt()
                resultPlates.add(PlateCount(plate, count))
                remainingPerSide -= count * plate
                remainingPerSide = (remainingPerSide * 100.0).roundToInt() / 100.0
            }
        }

        val actualWeightPerSide = resultPlates.sumOf { it.plateWeight * it.countPerSide }
        val actualTotalWeight = barWeight + actualWeightPerSide * 2.0
        val remainder = ((targetWeight - actualTotalWeight) * 10.0).roundToInt() / 10.0

        return PlateResult(
            targetWeight = targetWeight,
            barWeight = barWeight,
            weightPerSide = actualWeightPerSide,
            platesPerSide = resultPlates,
            actualTotalWeight = actualTotalWeight,
            remainder = remainder
        )
    }
}
