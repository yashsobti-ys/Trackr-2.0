package com.trackr.fitness.ui.screens.utilities

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trackr.fitness.domain.calculator.FitnessCalculators
import com.trackr.fitness.ui.theme.*

@Composable
fun UtilitiesScreen() {
    var targetWeightText by remember { mutableStateOf("225") }
    val targetWeight = targetWeightText.toDoubleOrNull() ?: 225.0
    val plateResult = FitnessCalculators.calculatePlates(targetWeight, 45.0, "lbs")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Lifting Utilities",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Text(
                    text = "Plate loader & 1RM calculator",
                    fontSize = 13.sp,
                    color = TextSecondary
                )
            }
        }

        // Plate Calculator Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Charcoal800),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Olympic Barbell Plate Loader", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Standard 45 lb Olympic Barbell", fontSize = 12.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = targetWeightText,
                        onValueChange = { targetWeightText = it },
                        label = { Text("Target Weight (lbs)") },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = LimeGreen,
                            unfocusedBorderColor = BorderDark
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Per Side: ${plateResult.weightPerSide} lbs",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = LimeGreen
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    if (plateResult.platesPerSide.isEmpty()) {
                        Text("Bar only (no plates needed)", fontSize = 13.sp, color = TextMuted)
                    } else {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            plateResult.platesPerSide.forEach { plate ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(Charcoal700)
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "${plate.countPerSide}x ${plate.plateWeight.toInt()} lb",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // 1RM Quick Matrix Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Charcoal800),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("1RM Training Zones", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Percentages based on $targetWeight lbs max", fontSize = 12.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(10.dp))

                    listOf(
                        Triple(100, 1.0, "1 rep - True Max"),
                        Triple(90, 0.9, "3-4 reps - Strength"),
                        Triple(80, 0.8, "7-8 reps - Hypertrophy"),
                        Triple(70, 0.7, "10-12 reps - Volume")
                    ).forEach { (pct, factor, reps) ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("$pct%", fontWeight = FontWeight.SemiBold, color = LimeGreen, fontSize = 13.sp)
                            Text("${(targetWeight * factor).toInt()} lbs", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 13.sp)
                            Text(reps, color = TextMuted, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
