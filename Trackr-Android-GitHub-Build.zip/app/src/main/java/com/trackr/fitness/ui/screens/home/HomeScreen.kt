package com.trackr.fitness.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.trackr.fitness.ui.theme.Charcoal800
import com.trackr.fitness.ui.theme.LimeGreen
import com.trackr.fitness.ui.theme.TextMuted
import com.trackr.fitness.ui.theme.TextSecondary

@Composable
fun HomeScreen(
    onStartEmptyWorkout: () -> Unit,
    onNavigateToRoutines: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "Welcome Back",
                    fontSize = 14.sp,
                    color = TextMuted,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "Ready to Train?",
                    fontSize = 26.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        }

        // Quick Start Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Charcoal800),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Quick Start",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = Color.White
                    )
                    Text(
                        text = "Log an empty workout without a pre-set routine.",
                        fontSize = 13.sp,
                        color = TextSecondary,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = onStartEmptyWorkout,
                        colors = ButtonDefaults.buttonColors(containerColor = LimeGreen),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "Start Empty Workout", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Training stats row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                StatCard(
                    title = "Workouts This Week",
                    value = "3",
                    unit = "sessions",
                    modifier = Modifier.weight(1f)
                )
                StatCard(
                    title = "Total Volume",
                    value = "43.4k",
                    unit = "lbs lifted",
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Starter routines header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Quick Routines",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                TextButton(onClick = onNavigateToRoutines) {
                    Text("View All", color = LimeGreen)
                }
            }
        }

        // Routine Quick Cards
        item {
            RoutineQuickCard(
                title = "Push Day (Hypertrophy)",
                exercisesCount = 5,
                estimatedMinutes = 60,
                onStart = onStartEmptyWorkout
            )
        }
        item {
            RoutineQuickCard(
                title = "Pull Day (Deadlifts & Back)",
                exercisesCount = 6,
                estimatedMinutes = 65,
                onStart = onStartEmptyWorkout
            )
        }
        item {
            RoutineQuickCard(
                title = "Leg Day (Squats & Quads)",
                exercisesCount = 5,
                estimatedMinutes = 65,
                onStart = onStartEmptyWorkout
            )
        }
    }
}

@Composable
fun StatCard(title: String, value: String, unit: String, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Charcoal800),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(text = title, fontSize = 12.sp, color = TextMuted)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = LimeGreen)
            Text(text = unit, fontSize = 11.sp, color = TextSecondary)
        }
    }
}

@Composable
fun RoutineQuickCard(
    title: String,
    exercisesCount: Int,
    estimatedMinutes: Int,
    onStart: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Charcoal800)
            .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, color = Color.White)
            Text(text = "$exercisesCount exercises • ~$estimatedMinutes min", fontSize = 12.sp, color = TextMuted)
        }
        IconButton(
            onClick = onStart,
            colors = IconButtonDefaults.iconButtonColors(containerColor = LimeGreen)
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = "Start", tint = Color.Black)
        }
    }
}
