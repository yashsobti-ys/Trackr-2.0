package com.trackr.fitness.domain.engine

import org.junit.Assert.*
import org.junit.Before
import org.junit.Test

class WorkoutSessionEngineTest {

    private lateinit var engine: WorkoutSessionEngine

    @Before
    fun setUp() {
        engine = WorkoutSessionEngine()
    }

    @Test
    fun testStartSessionTransitionsToActive() {
        val exercises = listOf(
            ActiveWorkoutExercise(
                id = "we-1",
                exerciseId = "ex-bench-press",
                exerciseName = "Barbell Bench Press",
                muscleGroup = "Chest",
                equipment = "Barbell",
                sets = listOf(
                    ActiveWorkoutSet(id = "s-1", setNumber = 1, type = "normal", weight = 185.0, reps = 8)
                )
            )
        )

        val session = engine.startSession("sess-1", "Chest Day", exercises)
        assertEquals(SessionState.ACTIVE, session.state)
        assertEquals("sess-1", session.sessionId)
        assertEquals(1, session.exercises.size)
    }

    @Test
    fun testCrashRecoveryPreservesActiveSession() {
        val snapshot = ActiveSessionSnapshot(
            sessionId = "recovered-session-123",
            title = "Recovered Workout",
            state = SessionState.ACTIVE,
            startTimeMs = 1700000000000L,
            elapsedTimeSeconds = 1840,
            exercises = listOf(
                ActiveWorkoutExercise(
                    id = "we-2",
                    exerciseId = "ex-squat",
                    exerciseName = "Barbell Squat",
                    muscleGroup = "Quads",
                    equipment = "Barbell",
                    sets = listOf(
                        ActiveWorkoutSet(id = "s-2", setNumber = 1, type = "normal", weight = 225.0, reps = 5, isCompleted = true)
                    )
                )
            )
        )

        val recovered = engine.recoverSession(snapshot)
        assertEquals(SessionState.ACTIVE, recovered.state)
        assertEquals(1840L, recovered.elapsedTimeSeconds)
        assertTrue(recovered.exercises[0].sets[0].isCompleted)
    }

    @Test
    fun testToggleSetCompletion() {
        val exercises = listOf(
            ActiveWorkoutExercise(
                id = "we-1",
                exerciseId = "ex-bench",
                exerciseName = "Bench",
                muscleGroup = "Chest",
                equipment = "Barbell",
                sets = listOf(
                    ActiveWorkoutSet(id = "s-1", setNumber = 1, type = "normal", weight = 135.0, reps = 10, isCompleted = false)
                )
            )
        )
        engine.startSession("sess-toggle", "Toggle Test", exercises)

        val updated = engine.toggleSetCompletion("we-1", "s-1")
        assertNotNull(updated)
        assertTrue(updated!!.exercises[0].sets[0].isCompleted)

        // Toggle back
        val reverted = engine.toggleSetCompletion("we-1", "s-1")
        assertNotNull(reverted)
        assertFalse(reverted!!.exercises[0].sets[0].isCompleted)
    }

    @Test
    fun testCompletionPreventsDuplicates() {
        val exercises = listOf(
            ActiveWorkoutExercise(
                id = "we-1",
                exerciseId = "ex-bench",
                exerciseName = "Bench",
                muscleGroup = "Chest",
                equipment = "Barbell",
                sets = emptyList()
            )
        )
        engine.startSession("sess-complete", "Complete Test", exercises)
        val finished1 = engine.completeSession()
        assertEquals(SessionState.COMPLETED, finished1?.state)

        // Second completion call does not mutate state or re-fire
        val finished2 = engine.completeSession()
        assertEquals(SessionState.COMPLETED, finished2?.state)
    }
}
