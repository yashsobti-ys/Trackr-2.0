package com.trackr.fitness.domain.calculator

import org.junit.Assert.assertEquals
import org.junit.Test

class FitnessCalculatorsTest {

    @Test
    fun testEpley1RMCalculation() {
        // 1 rep should equal exact weight lifted
        assertEquals(225.0, FitnessCalculators.calculateEpley1RM(225.0, 1), 0.01)

        // 200 lbs for 10 reps: 200 * (1 + 10/30) = 200 * 1.3333 = 266.7
        val est1RM = FitnessCalculators.calculateEpley1RM(200.0, 10)
        assertEquals(266.7, est1RM, 0.1)

        // Zero or negative input protection
        assertEquals(0.0, FitnessCalculators.calculateEpley1RM(0.0, 5), 0.01)
        assertEquals(0.0, FitnessCalculators.calculateEpley1RM(200.0, 0), 0.01)
    }

    @Test
    fun testBrzycki1RMCalculation() {
        // 1 rep should equal exact weight lifted
        assertEquals(225.0, FitnessCalculators.calculateBrzycki1RM(225.0, 1), 0.01)

        // 200 lbs for 5 reps: 200 * (36 / (37 - 5)) = 200 * (36/32) = 225.0
        val est1RM = FitnessCalculators.calculateBrzycki1RM(200.0, 5)
        assertEquals(225.0, est1RM, 0.1)
    }

    @Test
    fun testPlateCalculatorStandardBarbell() {
        // 225 lbs on 45 lb bar -> 90 lbs per side -> two 45 lb plates per side
        val result = FitnessCalculators.calculatePlates(225.0, 45.0, "lbs")
        assertEquals(90.0, result.weightPerSide, 0.01)
        assertEquals(225.0, result.actualTotalWeight, 0.01)
        assertEquals(0.0, result.remainder, 0.01)
        assertEquals(1, result.platesPerSide.size)
        assertEquals(45.0, result.platesPerSide[0].plateWeight, 0.01)
        assertEquals(2, result.platesPerSide[0].countPerSide)
    }

    @Test
    fun testPlateCalculatorBarOnly() {
        val result = FitnessCalculators.calculatePlates(45.0, 45.0, "lbs")
        assertEquals(0.0, result.weightPerSide, 0.01)
        assertEquals(0, result.platesPerSide.size)
        assertEquals(45.0, result.actualTotalWeight, 0.01)
    }
}
